# COPAG Logistics Dashboard

Single-file Streamlit dashboard (`app.py`) to analyse COPAG shipments across Morocco:
delays, costs, fuel, speed, CO₂ and cold chain.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Data
No data file is bundled. After signing in, either:
- upload `copag_logistics.csv` with the uploader shown on screen, or
- place `copag_logistics.csv` in the same folder as `app.py` (it is then loaded automatically).

## Login
Username: `marwa` (the password is stored as a SHA-256 hash inside `app.py`; edit `USERNAME` / `PASSWORD_HASH` to change it).

## What `app.py` contains
1. Login (with lock after 5 failed attempts)
2. Data cleaning (trim text, parse dates, remove duplicates / missing / impossible values, derived columns)
3. KPIs and automatic insights
4. Sidebar filters (region, mode, product, period)
5. Matplotlib / Seaborn charts + maps (st.map and PyDeck arcs)
6. Dashboard with 6 tabs: Overview, Performance, Costs & Emissions, Cold Chain & Fleet, Maps, Data
