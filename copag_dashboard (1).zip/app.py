"""COPAG Logistics Analytics - single-file Streamlit dashboard.

Run with:  streamlit run app.py
"""
import hashlib
import hmac
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import pydeck as pdk
import seaborn as sns
import streamlit as st

st.set_page_config(page_title="COPAG Logistics", page_icon="🚚", layout="wide")

# =====================================================================
# 0. STYLE
# =====================================================================
GREEN, TEAL, ORANGE, RED = "#0E7C66", "#14B8A6", "#F59E0B", "#DC2626"
PALETTE = ["#0E7C66", "#14B8A6", "#F59E0B", "#3B82F6", "#8B5CF6", "#EC4899", "#64748B"]

sns.set_theme(style="whitegrid", palette=PALETTE)
plt.rcParams.update({
    "axes.titlesize": 13, "axes.titleweight": "bold", "axes.labelsize": 10,
    "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 110,
})

CSS = """
<style>
#MainMenu, footer {visibility: hidden;}
.block-container {padding-top: 1.6rem; max-width: 1280px;}
.hero {background: linear-gradient(120deg,#0E7C66 0%,#14B8A6 100%); color:#fff; padding:1.4rem 1.8rem;
       border-radius:18px; margin-bottom:1.2rem; box-shadow:0 6px 20px rgba(14,124,102,.25);}
.hero h1 {margin:0; font-size:1.8rem; color:#fff;}
.hero p {margin:.2rem 0 0; opacity:.9;}
.kpi {background:#fff; border:1px solid #E2ECE9; border-radius:16px; padding:1rem 1.1rem;
      box-shadow:0 2px 8px rgba(18,51,43,.06); height:100%;}
.kpi .label {font-size:.75rem; color:#64748B; text-transform:uppercase; letter-spacing:.04em; font-weight:600;}
.kpi .value {font-size:1.6rem; font-weight:700; color:#0E7C66; line-height:1.25;}
.kpi .sub {font-size:.75rem; color:#94A3B8;}
.section-title {font-size:1.05rem; font-weight:700; margin:1.2rem 0 .4rem;}
.insight {background:#F1F6F4; color:#12332B; border-left:4px solid #0E7C66; padding:.6rem .9rem;
          border-radius:8px; margin-bottom:.5rem;}
.login-card {text-align:center; margin-top:5vh; margin-bottom:1rem;}
.login-card h1 {color:#0E7C66; margin:.2rem 0;}
.login-card p {color:#64748B;}
.login-logo {font-size:3rem;}
div[data-testid="stTabs"] button {font-weight:600;}
</style>
"""


def hero(title, subtitle):
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def kpi_card(label, value, sub=""):
    st.markdown(
        f'<div class="kpi"><div class="label">{label}</div><div class="value">{value}</div>'
        f'<div class="sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def section(title):
    st.markdown(f'<div class="section-title">{title}</div>', unsafe_allow_html=True)


# =====================================================================
# 1. AUTHENTICATION
# =====================================================================
USERNAME = "marwa"
PASSWORD_HASH = hashlib.sha256("Marwabdf34".encode("utf-8")).hexdigest()
MAX_ATTEMPTS = 5


def check_credentials(username, password):
    user_ok = hmac.compare_digest(username.strip().lower(), USERNAME)
    pwd_ok = hmac.compare_digest(hashlib.sha256(password.encode("utf-8")).hexdigest(), PASSWORD_HASH)
    return user_ok and pwd_ok


def login_page():
    st.session_state.setdefault("attempts", 0)
    _, center, _ = st.columns([1, 1.2, 1])
    with center:
        st.markdown(
            '<div class="login-card"><div class="login-logo">🚚</div><h1>COPAG Logistics</h1>'
            "<p>Sign in to access the analytics dashboard</p></div>",
            unsafe_allow_html=True,
        )
        locked = st.session_state["attempts"] >= MAX_ATTEMPTS
        with st.form("login_form"):
            username = st.text_input("Username", placeholder="Enter your username")
            password = st.text_input("Password", type="password", placeholder="Enter your password")
            submitted = st.form_submit_button("Sign in", use_container_width=True, disabled=locked)
        if submitted:
            if check_credentials(username, password):
                st.session_state["authenticated"] = True
                st.session_state["attempts"] = 0
                st.rerun()
            else:
                st.session_state["attempts"] += 1
                left = MAX_ATTEMPTS - st.session_state["attempts"]
                st.error("Invalid username or password." + (f" {left} attempt(s) left." if left > 0 else ""))
        if locked:
            st.warning("Too many failed attempts. Refresh the page to try again.")


# =====================================================================
# 2. DATA LOADING & CLEANING
# =====================================================================
LOCAL_CSV = Path(__file__).resolve().parent / "copag_logistics.csv"

NUMERIC_COLS = [
    "o_lat", "o_lon", "d_lat", "d_lon", "distance_km", "planned_duration_min", "actual_duration_min",
    "delay_min", "on_time", "temperature_breach", "capacity_utilization", "fuel_liters", "co2_kg",
    "cost_mad", "quantity_tons", "lat", "lon",
]
TEXT_COLS = ["shipment_id", "origin_hub", "origin_region", "destination_city", "destination_region",
             "mode", "product_category", "temperature_req"]


def clean_data(raw):
    """Return (clean_df, report) where report is a list of (step, rows)."""
    missing = [c for c in TEXT_COLS + NUMERIC_COLS + ["date"] if c not in raw.columns]
    if missing:
        raise ValueError(f"Missing columns in the CSV: {', '.join(missing)}")

    df = raw.copy()
    report = [("Raw rows loaded", len(df))]

    for c in TEXT_COLS:
        df[c] = df[c].astype(str).str.strip()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in NUMERIC_COLS:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    n = len(df)
    df = df.drop_duplicates(subset="shipment_id")
    report.append(("Duplicate shipments removed", n - len(df)))

    critical = ["date", "distance_km", "on_time", "cost_mad", "fuel_liters", "co2_kg",
                "actual_duration_min", "planned_duration_min"]
    n = len(df)
    df = df.dropna(subset=critical)
    report.append(("Rows with missing critical values removed", n - len(df)))

    n = len(df)
    valid = ((df["actual_duration_min"] > 0) & (df["planned_duration_min"] > 0)
             & (df["distance_km"] > 0) & (df["cost_mad"] > 0))
    df = df[valid].copy()
    report.append(("Rows with impossible values removed (duration <= 0, ...)", n - len(df)))

    for c in ["on_time", "temperature_breach"]:
        df[c] = df[c].fillna(0).round().clip(0, 1).astype(int)

    df["lane"] = df["origin_hub"] + " → " + df["destination_city"]
    df["cost_per_km"] = df["cost_mad"] / df["distance_km"]
    df["avg_speed_kmh"] = df["distance_km"] / (df["actual_duration_min"] / 60)
    df["month"] = df["date"].dt.to_period("M").dt.to_timestamp()

    q1, q3 = df["cost_per_km"].quantile([0.25, 0.75])
    iqr = q3 - q1
    outliers = (df["cost_per_km"] > q3 + 3 * iqr) | (df["cost_per_km"] < q1 - 3 * iqr)
    report.append(("Cost/km outliers detected (kept in data)", int(outliers.sum())))

    df = df.sort_values("date").reset_index(drop=True)
    report.append(("Clean rows available for analysis", len(df)))
    return df, report


@st.cache_data(show_spinner="Cleaning data...")
def prepare(raw):
    return clean_data(raw)


def get_raw_data():
    """CSV next to app.py if present, otherwise ask the user to upload it."""
    if LOCAL_CSV.exists():
        return pd.read_csv(LOCAL_CSV)
    st.info("Upload the **copag_logistics.csv** file to start the analysis.")
    up = st.file_uploader("CSV file", type="csv")
    if up is None:
        return None
    return pd.read_csv(up)


# =====================================================================
# 3. KPIs & INSIGHTS
# =====================================================================
def compute_kpis(df):
    return {
        "shipments": len(df),
        "on_time_rate": df["on_time"].mean() * 100,
        "avg_cost": df["cost_mad"].mean(),
        "avg_fuel": df["fuel_liters"].mean(),
        "avg_co2": df["co2_kg"].mean(),
        "total_cost": df["cost_mad"].sum(),
        "avg_speed": df["avg_speed_kmh"].mean(),
        "breach_rate": df["temperature_breach"].mean() * 100,
        "total_tons": df["quantity_tons"].sum(),
    }


def build_insights(df):
    out = []
    lane = df["lane"].value_counts()
    out.append(f"**Busiest lane:** {lane.index[0]} with {lane.iloc[0]} shipments.")
    cpk = df.groupby("destination_region")["cost_per_km"].mean().sort_values(ascending=False)
    out.append(f"**Most expensive region per km:** {cpk.index[0]} ({cpk.iloc[0]:.2f} MAD/km), "
               f"vs {cpk.index[-1]} ({cpk.iloc[-1]:.2f} MAD/km) for the cheapest.")
    ot = df.groupby("destination_region")["on_time"].mean().sort_values()
    out.append(f"**Weakest punctuality:** {ot.index[0]} ({ot.iloc[0] * 100:.1f}% on time).")
    pb = df.groupby("product_category")["temperature_breach"].mean().sort_values(ascending=False)
    if pb.iloc[0] > 0:
        out.append(f"**Highest cold-chain breach rate:** {pb.index[0]} ({pb.iloc[0] * 100:.1f}%).")
    else:
        out.append("**Cold chain:** no temperature breach in the selected data.")
    pdl = df.groupby("product_category")["delay_min"].mean().sort_values(ascending=False)
    out.append(f"**Longest average delay by product:** {pdl.index[0]} ({pdl.iloc[0]:.1f} min).")
    co2 = df.groupby("origin_hub")["co2_kg"].mean().sort_values(ascending=False)
    out.append(f"**Highest CO₂ per trip by hub:** {co2.index[0]} ({co2.iloc[0]:.0f} kg).")
    return out


# =====================================================================
# 4. FILTERS
# =====================================================================
ALL = "All"


def _options(series):
    return [ALL] + sorted(series.dropna().unique().tolist())


def apply_filters(df):
    st.sidebar.markdown("### 🔎 Filters")
    region = st.sidebar.selectbox("Destination region", _options(df["destination_region"]))
    mode = st.sidebar.selectbox("Transport mode", _options(df["mode"]))
    product = st.sidebar.selectbox("Product category", _options(df["product_category"]))

    dmin, dmax = df["date"].min().date(), df["date"].max().date()
    period = st.sidebar.date_input("Period", value=(dmin, dmax), min_value=dmin, max_value=dmax)

    out = df
    if region != ALL:
        out = out[out["destination_region"] == region]
    if mode != ALL:
        out = out[out["mode"] == mode]
    if product != ALL:
        out = out[out["product_category"] == product]

    if isinstance(period, (tuple, list)):
        if len(period) == 2:
            start, end = period
        elif len(period) == 1:
            start = end = period[0]
        else:
            start, end = dmin, dmax
    else:
        start = end = period
    out = out[(out["date"].dt.date >= start) & (out["date"].dt.date <= end)]

    st.sidebar.caption(f"{len(out):,} / {len(df):,} shipments selected")
    return out


# =====================================================================
# 5. CHARTS (Matplotlib + Seaborn)
# =====================================================================
def _fig(w=7, h=4):
    return plt.subplots(figsize=(w, h))


def _rotate(ax):
    plt.setp(ax.get_xticklabels(), rotation=40, ha="right", fontsize=8)


def show(fig):
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)


def chart_on_time(df):
    d = df.groupby("date", as_index=False)["on_time"].mean()
    d["rate"] = d["on_time"] * 100
    d["smooth"] = d["rate"].rolling(14, min_periods=1).mean()
    fig, ax = _fig()
    ax.plot(d["date"], d["rate"], color=TEAL, alpha=0.35, lw=1, label="Daily")
    ax.plot(d["date"], d["smooth"], color=GREEN, lw=2.2, label="14-day average")
    ax.axhline(df["on_time"].mean() * 100, color=ORANGE, ls="--", lw=1, label="Overall average")
    ax.set(title="Daily On-Time Performance", xlabel="Date", ylabel="On-time rate (%)", ylim=(0, 105))
    ax.legend(frameon=False, fontsize=8)
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig


def chart_top_lanes(df, n=10):
    t = df["lane"].value_counts().head(n).reset_index()
    t.columns = ["lane", "count"]
    fig, ax = _fig()
    sns.barplot(data=t, x="count", y="lane", color=GREEN, ax=ax)
    ax.bar_label(ax.containers[0], padding=3, fontsize=8)
    ax.set(title="Top 10 Routes by Volume", xlabel="Number of shipments", ylabel="")
    fig.tight_layout()
    return fig


def chart_delay_box(df):
    fig, ax = _fig()
    sns.boxplot(data=df, x="delay_min", y="product_category", color=TEAL, fliersize=2, ax=ax)
    ax.axvline(0, color=RED, ls="--", lw=1)
    ax.set(title="Delivery Delay by Product Type", xlabel="Delay (min)", ylabel="")
    fig.tight_layout()
    return fig


def chart_heatmap(df):
    cols = ["distance_km", "planned_duration_min", "actual_duration_min", "delay_min", "on_time",
            "temperature_breach", "capacity_utilization", "fuel_liters", "co2_kg", "cost_mad", "quantity_tons"]
    fig, ax = _fig(7, 5.2)
    sns.heatmap(df[cols].corr(), annot=True, fmt=".2f", cmap="RdYlGn", center=0,
                annot_kws={"size": 7}, cbar_kws={"shrink": 0.8}, ax=ax)
    ax.set_title("Correlation Heatmap")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", fontsize=8)
    plt.setp(ax.get_yticklabels(), fontsize=8)
    fig.tight_layout()
    return fig


def chart_cost_per_km(df):
    d = df.groupby("destination_region", as_index=False)["cost_per_km"].mean().sort_values("cost_per_km", ascending=False)
    fig, ax = _fig()
    ax.bar(d["destination_region"], d["cost_per_km"], color=GREEN)
    ax.bar_label(ax.containers[0], fmt="%.1f", fontsize=8, padding=2)
    ax.set(title="Average Cost per km by Region", xlabel="", ylabel="MAD / km")
    _rotate(ax)
    fig.tight_layout()
    return fig


def chart_pie(df):
    c = df["product_category"].value_counts()
    fig, ax = _fig(6, 4.5)
    ax.pie(c.values, labels=c.index, autopct="%1.1f%%", startangle=90, colors=PALETTE,
           wedgeprops={"width": 0.45, "edgecolor": "white"}, textprops={"fontsize": 8})
    ax.set_title("Shipment Share by Product")
    ax.axis("equal")
    fig.tight_layout()
    return fig


def chart_delay_hist(df):
    fig, ax = _fig()
    sns.histplot(df["delay_min"], bins=30, color=TEAL, kde=True, ax=ax)
    ax.axvline(0, color=RED, ls="--", lw=1)
    ax.set(title="Delay Distribution", xlabel="Delay (min)", ylabel="Shipments")
    fig.tight_layout()
    return fig


def chart_delay_region(df):
    d = df.groupby("destination_region", as_index=False)["delay_min"].mean().sort_values("delay_min", ascending=False)
    fig, ax = _fig()
    ax.bar(d["destination_region"], d["delay_min"], color=ORANGE)
    ax.set(title="Average Delay by Region", xlabel="", ylabel="Minutes")
    _rotate(ax)
    fig.tight_layout()
    return fig


def chart_scatter(df, y, title, ylabel):
    fig, ax = _fig()
    sns.scatterplot(data=df, x="distance_km", y=y, hue="mode", alpha=0.6, s=28, ax=ax,
                    palette={"Reefer": GREEN, "Dry Van": ORANGE})
    ax.set(title=title, xlabel="Distance (km)", ylabel=ylabel)
    ax.legend(frameon=False, fontsize=8, title="Mode")
    fig.tight_layout()
    return fig


def chart_cost_product(df):
    d = df.groupby("product_category", as_index=False)["cost_mad"].mean().sort_values("cost_mad", ascending=False)
    fig, ax = _fig()
    ax.bar(d["product_category"], d["cost_mad"], color=GREEN)
    ax.set(title="Average Cost by Product", xlabel="", ylabel="MAD")
    _rotate(ax)
    fig.tight_layout()
    return fig


def chart_monthly(df):
    m = df.groupby("month").agg(cost=("cost_mad", "sum"), co2=("co2_kg", "sum")).reset_index()
    fig, ax = _fig()
    ax.bar(m["month"], m["cost"], width=20, color=GREEN, alpha=0.85)
    ax.set(title="Monthly Transport Cost & CO₂", xlabel="", ylabel="Total cost (MAD)")
    ax2 = ax.twinx()
    ax2.plot(m["month"], m["co2"], color=ORANGE, marker="o", lw=2)
    ax2.set_ylabel("Total CO₂ (kg)")
    ax2.grid(False)
    ax2.spines["right"].set_visible(True)
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig


def chart_breach(df):
    d = df.groupby("product_category", as_index=False)["temperature_breach"].mean()
    d["rate"] = d["temperature_breach"] * 100
    d = d.sort_values("rate", ascending=False)
    fig, ax = _fig()
    ax.bar(d["product_category"], d["rate"], color=RED)
    ax.bar_label(ax.containers[0], fmt="%.1f%%", fontsize=8, padding=2)
    ax.set(title="Temperature Breach Rate by Product", xlabel="", ylabel="Breach rate (%)")
    _rotate(ax)
    fig.tight_layout()
    return fig


def chart_capacity(df):
    d = df.groupby("mode", as_index=False)["capacity_utilization"].mean()
    fig, ax = _fig(6, 4)
    ax.bar(d["mode"], d["capacity_utilization"] * 100, color=[GREEN, ORANGE][: len(d)], width=0.5)
    ax.bar_label(ax.containers[0], fmt="%.1f%%", fontsize=9, padding=2)
    ax.set(title="Average Capacity Utilization by Transport Mode", xlabel="", ylabel="Utilization (%)", ylim=(0, 100))
    fig.tight_layout()
    return fig


def chart_speed(df):
    fig, ax = _fig()
    sns.violinplot(data=df, x="mode", y="avg_speed_kmh", hue="mode",
                   palette={"Reefer": GREEN, "Dry Van": ORANGE}, legend=False, inner="quartile", ax=ax)
    ax.set(title="Average Speed by Transport Mode", xlabel="", ylabel="km/h")
    fig.tight_layout()
    return fig


# =====================================================================
# 6. DASHBOARD
# =====================================================================
def kpi_row(k):
    items = [
        ("Shipments", f"{k['shipments']:,}", f"{k['total_tons']:,.0f} tons moved"),
        ("On-Time Rate", f"{k['on_time_rate']:.1f}%", "deliveries on schedule"),
        ("Avg Cost", f"{k['avg_cost']:,.0f} MAD", f"{k['total_cost'] / 1e6:.2f} M MAD total"),
        ("Fuel / Ship", f"{k['avg_fuel']:.1f} L", f"avg speed {k['avg_speed']:.0f} km/h"),
        ("CO₂ / Ship", f"{k['avg_co2']:.1f} kg", f"cold-chain breaches {k['breach_rate']:.1f}%"),
    ]
    for col, (label, value, sub) in zip(st.columns(5), items):
        with col:
            kpi_card(label, value, sub)


def dashboard():
    st.sidebar.markdown("## 🚚 COPAG")
    st.sidebar.caption("Logistics & Transport Analytics")
    st.sidebar.markdown("---")

    hero("COPAG Logistics Dashboard", "Monitor deliveries, delays, costs, fuel and CO₂ across Morocco")

    raw = get_raw_data()
    if raw is None:
        sign_out_button()
        return
    try:
        df_all, report = prepare(raw)
    except ValueError as e:
        st.error(str(e))
        sign_out_button()
        return
    if df_all.empty:
        st.error("No valid rows after cleaning.")
        sign_out_button()
        return

    fdf = apply_filters(df_all)
    sign_out_button()

    if fdf.empty:
        st.warning("No shipment matches the selected filters. Please widen your selection.")
        return

    kpi_row(compute_kpis(fdf))

    tab_over, tab_perf, tab_cost, tab_cold, tab_map, tab_data = st.tabs(
        ["📊 Overview", "⏱️ Performance", "💰 Costs & Emissions", "❄️ Cold Chain & Fleet", "🗺️ Maps", "🗂️ Data"]
    )

    with tab_over:
        section("Performance & routes")
        c1, c2 = st.columns(2)
        with c1:
            show(chart_on_time(fdf))
        with c2:
            show(chart_top_lanes(fdf))
        section("Key insights")
        for line in build_insights(fdf):
            st.markdown(f'<div class="insight">{line}</div>', unsafe_allow_html=True)

    with tab_perf:
        section("Delays & correlations")
        c1, c2 = st.columns(2)
        with c1:
            show(chart_delay_box(fdf))
        with c2:
            show(chart_heatmap(fdf))
        c3, c4 = st.columns(2)
        with c3:
            show(chart_delay_hist(fdf))
        with c4:
            show(chart_delay_region(fdf))

    with tab_cost:
        section("Costs & distribution")
        c1, c2 = st.columns(2)
        with c1:
            show(chart_cost_per_km(fdf))
        with c2:
            show(chart_pie(fdf))
        section("Distance vs cost, fuel and CO₂")
        c3, c4, c5 = st.columns(3)
        with c3:
            show(chart_scatter(fdf, "cost_mad", "Distance vs Cost", "Cost (MAD)"))
        with c4:
            show(chart_scatter(fdf, "fuel_liters", "Distance vs Fuel", "Fuel (L)"))
        with c5:
            show(chart_scatter(fdf, "co2_kg", "Distance vs CO₂", "CO₂ (kg)"))
        c6, c7 = st.columns(2)
        with c6:
            show(chart_cost_product(fdf))
        with c7:
            show(chart_monthly(fdf))

    with tab_cold:
        c1, c2 = st.columns(2)
        with c1:
            show(chart_breach(fdf))
        with c2:
            show(chart_capacity(fdf))
        show(chart_speed(fdf))

    with tab_map:
        section("Fleet current positions")
        st.map(fdf[["lat", "lon"]].dropna(), latitude="lat", longitude="lon", size=2000, color="#0E7C66")
        section("Route flows between hubs and cities")
        flows = (fdf.groupby(["origin_hub", "destination_city", "o_lat", "o_lon", "d_lat", "d_lon"], as_index=False)
                 .size().rename(columns={"size": "count"}))
        flows["width"] = 1 + flows["count"] / flows["count"].max() * 8
        arcs = pdk.Layer(
            "ArcLayer", data=flows,
            get_source_position=["o_lon", "o_lat"], get_target_position=["d_lon", "d_lat"],
            get_width="width", get_source_color=[14, 124, 102, 180], get_target_color=[245, 158, 11, 180],
            pickable=True,
        )
        view = pdk.ViewState(latitude=31.5, longitude=-8.0, zoom=4.6, pitch=30)
        st.pydeck_chart(
            pdk.Deck(layers=[arcs], initial_view_state=view,
                     tooltip={"text": "{origin_hub} → {destination_city}\n{count} shipments"}),
            use_container_width=True,
        )

    with tab_data:
        section("Data cleaning report")
        st.dataframe(pd.DataFrame(report, columns=["Step", "Rows"]), hide_index=True, use_container_width=True)
        section("Filtered data")
        st.dataframe(fdf.drop(columns=["month"]), use_container_width=True, height=380)
        st.download_button("⬇️ Download filtered data (CSV)", fdf.to_csv(index=False).encode("utf-8"),
                           file_name="copag_filtered.csv", mime="text/csv")


def sign_out_button():
    st.sidebar.markdown("---")
    st.sidebar.caption(f"Signed in as **{USERNAME}**")
    if st.sidebar.button("Sign out", use_container_width=True):
        st.session_state["authenticated"] = False
        st.session_state["attempts"] = 0
        st.rerun()


def main():
    st.markdown(CSS, unsafe_allow_html=True)
    if st.session_state.get("authenticated", False):
        dashboard()
    else:
        login_page()


main()
